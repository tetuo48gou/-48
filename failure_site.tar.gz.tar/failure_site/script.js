// 投稿をローカルストレージから取得
function loadPosts() {
  const stored = localStorage.getItem('failurePosts');
  try {
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
}

// 投稿をローカルストレージに保存
function savePosts(posts) {
  localStorage.setItem('failurePosts', JSON.stringify(posts));
}

// 日付を整形する
function formatDate(date) {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const hh = String(date.getHours()).padStart(2, '0');
  const mi = String(date.getMinutes()).padStart(2, '0');
  return `${yyyy}/${mm}/${dd} ${hh}:${mi}`;
}

// 投稿一覧を表示
function renderPosts() {
  const postsContainer = document.getElementById('posts-container');
  postsContainer.innerHTML = '';
  const posts = loadPosts();
  if (posts.length === 0) {
    const emptyMsg = document.createElement('p');
    emptyMsg.textContent = 'まだ投稿はありません。最初の投稿をしてみませんか？';
    postsContainer.appendChild(emptyMsg);
    return;
  }
  posts.forEach((post, index) => {
    const postDiv = document.createElement('div');
    postDiv.className = 'post';
    // ヘッダー
    const headerDiv = document.createElement('div');
    headerDiv.className = 'post-header';
    const authorSpan = document.createElement('span');
    authorSpan.className = 'post-author';
    authorSpan.textContent = post.author || '匿名';
    const dateSpan = document.createElement('span');
    dateSpan.className = 'post-date';
    dateSpan.textContent = post.date;
    headerDiv.appendChild(authorSpan);
    headerDiv.appendChild(dateSpan);
    // 本文
    const contentP = document.createElement('p');
    contentP.className = 'post-content';
    contentP.textContent = post.content;
    // 削除ボタン
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = '削除';
    deleteBtn.className = 'delete-btn';
    deleteBtn.setAttribute('data-index', index);
    deleteBtn.addEventListener('click', () => {
      removePost(index);
    });
    postDiv.appendChild(headerDiv);
    postDiv.appendChild(contentP);
    postDiv.appendChild(deleteBtn);
    postsContainer.appendChild(postDiv);
  });
}

// 投稿を追加
function addPost(author, content) {
  const posts = loadPosts();
  posts.unshift({
    author: author.trim() || '匿名',
    content: content.trim(),
    date: formatDate(new Date())
  });
  savePosts(posts);
  renderPosts();
}

// 投稿を削除
function removePost(index) {
  const posts = loadPosts();
  posts.splice(index, 1);
  savePosts(posts);
  renderPosts();
}

// フォーム送信処理
document.addEventListener('DOMContentLoaded', () => {
  renderPosts();
  const form = document.getElementById('post-form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const author = document.getElementById('author').value;
    const content = document.getElementById('content').value;
    if (!content.trim()) {
      return;
    }
    addPost(author, content);
    // フォームをリセット
    form.reset();
  });
});